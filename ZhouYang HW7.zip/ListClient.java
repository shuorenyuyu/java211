import java.util.List;

/* 	CS211(A) Winter 2018 Assignment HW7
 	Team: Tan Fuzhuo, Zhou Yang 
 	Client class for HW7Project001. */

public class ListClient {
	public static void main(String[] args) {
		HW7Project001<Integer> list1 = new HW7Project001<Integer>();
		list1.add(18);
		list1.add(27);
		list1.add(93);
		list1.add(1);
		list1.add(2);
		list1.add(3);
		System.out.println(list1);
		list1.remove(1);
		System.out.println(list1);

		HW7Project001<Integer> list2 = new HW7Project001<Integer>();
		list2.add(18);
		list2.add(27);
		list2.add(93);
		list1.add(4);
		list1.add(5);
		list1.add(6);
		System.out.println(list2);
		list2.remove(1);
		System.out.println(list2);

		list1.addAll(2, list2);
		System.out.println(list1);

		int index = list1.lastIndexOf(6);
		System.out.println(index);

		list1.removeAll(list2);
		System.out.println(list1);
	}
}
