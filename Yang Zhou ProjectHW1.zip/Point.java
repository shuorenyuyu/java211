//YANG ZHOU   1/7/2018
/*          cs211 instructor :James      
* It's for question 18, 19.20 To construct rectangle and give point with width and height      */
class Point {
//member variables of class
	public int x;
	public int y;

public Point(){
	this(1,2);
	//calls point(int,int)constructor

}

public Point(int x, int y) {
	// TODO Auto-generated constructor stub
	this.x=x;
	this.y=y;
}//Returns the x-coordinate of this point
public final int getX(){
	return x;
}
public final int getY(){
	return y;
}
public void setX(int x){
	this.x=x;
}
public void setY(int y){
	this.y=y;
}
public String toString(){
	return"("+x+","+y+")";
}
}