/* 	CS211(A) Winter 2018 Assignment HW0
 	Tan Fuzhuo
 	This object work on Exercise 18,19,20,21,22 on page 583 to page 584.
 	This object represents a rectangle which may be modified, and accessed. */
public class Rectangle {
	int x;
	int y;
	int width;
	int height;

	public Rectangle(int x, int y, int width, int height) {
		if (width < 0 || height < 0)
			throw new IllegalArgumentException();

		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	// Rectangle Object declaration
	// width and height will not be negative, if they are throw the
	// IllegalArgumentException
	public int getHeight() {
		return height;
	}

	// get the height
	public int getWidth() {
		return width;
	}

	// get the width
	public int getX() {
		return x;
	}

	// get the x value
	public int getY() {
		return y;
	}

	// get the y value
	public String toString() {
		return "(x=" + x + ", y=" + y + ", width=" + width + ", height=" + height + ")";
	}

	// use to string method and string representation of the object
	public Rectangle(Point p, int width, int height) {
		this.x = p.getX();
		this.y = p.getY();
		this.width = width;
		this.height = height;
	}

	// the new Rectangle class use the point instead of the x, y value
	public boolean contains(int x, int y) {
		return this.x <= x && x <= this.x + width && this.y <= y && y <= this.y + height;
	}

	// the contains will decide the x, y coordinate lie inside the rectangle
	public boolean contains(Point p) {
		return contains(p.getX(), p.getY());
	}

	// the contains will decide the point lie inside the rectangle
	public Rectangle union(Rectangle rect) {
		int newX = Math.min(this.getX(), rect.getX());
		int newY = Math.min(this.getY(), rect.getY());
		// int the minimum value of x and y between two rectangle
		int newWidth = Math.max(rect.getX() + rect.getWidth() - newX, this.getX() + this.getWidth() - newX);
		int newHeight = Math.max(rect.getY() + rect.getHeight() - newY, this.getY() + this.getHeight() - newY);
		// int the maximum value of width and height between two rectangle
		return new Rectangle(newX, newY, newWidth, newHeight);
	}

	// the union will return a new rectangle and shouldn't modify rectangle
	public Rectangle intersection(Rectangle rect) {
		if (this.getX() + this.getWidth() < rect.getX() || rect.getX() + rect.getWidth() < this.getX()
				|| this.getY() + this.getHeight() < rect.getY() || rect.getY() + rect.getHeight() < this.getY())
			return null;
		// the rectangle will not have intersection with two rectangle and return null
		int startX = Math.max(this.getX(), rect.getX());
		int endX = Math.min(this.getX() + this.getWidth(), rect.getX() + rect.getWidth());
		int startY = Math.max(this.getY(), rect.getY());
		int endY = Math.min(this.getY() + this.getHeight(), rect.getY() + rect.getHeight());
		// int the start and end value for the rectangle
		return new Rectangle(startX, startY, endX - startX, endY - startY);
	}
	// the intersection will return a new rectangle and houldn't modify rectangle
}