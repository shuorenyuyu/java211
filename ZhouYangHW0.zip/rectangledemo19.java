//YANG ZHOU   1/7/2018
/*          cs211 instructor :James      
 * It's for question 19. To construct rectangle and give point with width and height      */
public class rectangledemo19 {
	
		public static void main(String[] args){
		Point p= new Point(1,2);
		//creating instance of class rectangle
		rectangle19 r=new rectangle19(p,3,4);
		//display rectangle data
		System.out.println(r);
	}
	}
