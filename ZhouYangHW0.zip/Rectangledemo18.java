//YANG ZHOU   1/7/2018
/*          cs211 instructor :James      
* It's for question 18, 19. To construct rectangle and give point with width and height      */
import java.awt.Point;

public class Rectangledemo18 {
    public static void main(String[] args){
    	//give a instance of class
    	rectangle re=new rectangle(1,2,3,4);
    	//print out data
    	System.out.println(re);
    	
    }
}

	