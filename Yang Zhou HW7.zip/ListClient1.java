
/* 	CS211(A) Winter 2018 Assignment HW7
 	Team: Tan Fuzhuo, Zhou Yang 
 	Client class for HW7Project001. */

public class ListClient1 {
	public static void main(String[] args) {
		HW7Project001<Integer> list1 = new HW7Project001<Integer>();
		list1.add(18);
		list1.add(27);
		list1.add(93);
		System.out.println(list1);
		list1.remove(1);
		System.out.println(list1);

		HW7Project001<Integer> list2 = new HW7Project001<Integer>();
		list2.add(18);
		list2.add(27);
		list2.add(93);
		System.out.println(list2);
		list2.remove(1);
		System.out.println(list2);
	}
}
