/* 	CS211(A) Winter 2018 Assignment EC01
 	Team: Tan Fuzhuo, Zhou Yang 
 	Client class for HashIntSet. */
public class EC01Exercise002 {
	public static void main(String[] args) {
		HashIntSet list1 = new HashIntSet();
		HashIntSet list2 = new HashIntSet();
		list1.add(1);
		list1.add(2);
		list1.add(3);
		list2.add(4);
		list2.add(1);
		list2.add(8);
		list2.add(9);
		System.out.println(list1);
		System.out.println(list2);
		System.out.println(list1.containsAll(list2));
	}
}
