/* 	CS211(A) Winter 2018 Assignment EC01
 	Team: Tan Fuzhuo, Zhou Yang 
 	This object work on Exercise 001 on page 1104, Exercise 002 on page 1104 and the HashIntSet class on page 1082. 
 	Exercise 001: Write a method named addAll that could be placed inside the HashIntSet class. This method accepts another HashIntSet as a parameter and adds all elements 
 	from that set into the current set, if they are not already present. For example, if a set s1 contains [1, 2, 3] and another set s2 contains [1, 7, 3, 9], the call of s1.
 	addAll(s2); would change s1 to store [1, 2, 3, 7, 9] in some order.
 	Exercise 002: Write a method in the HashIntSet class called containsAll that accepts another hash set as a parameter and returns true if your set contains every element 
 	from the other set. For example, if the set stores [-2, 3, 5, 6, 8] and the method is passed [3, 6, 8], your method would return true. If the method were passed [3, 6, 7, 8],
    your method would return false because your set does not contain the value 7.*/
public class HashIntSet {
	private static final double MAX_LOAD_FACTOR = 0.75;

	private HashEntry[] elementData;
	private int size;

	public HashIntSet() {
		elementData = (HashEntry[]) new HashEntry[10];
		size = 0;
	}

	public HashIntSet(int... values) {
		this();
		for (int value : values) {
			add(value);
		}
	}

	public void add(int value) {

		if (!contains(value)) {
			int h = hash(value);
			HashEntry newNode = new HashEntry(h);
			newNode.next = elementData[h];
			elementData[h] = newNode;
			size++;
		}

		if (loadFactor() > MAX_LOAD_FACTOR) {
			rehash();
		}
	}

	public boolean equals(Object o) {
		return equalsIgnoringSize(o) && size == ((HashIntSet) o).size();
	}

	public boolean equalsIgnoringSize(Object o) {
		if (o instanceof HashIntSet) {
			HashIntSet other = (HashIntSet) o;
			for (HashEntry front : elementData) {
				HashEntry current = front;
				while (current != null) {
					if (!other.contains(current.data)) {
						return false;
					}
					current = current.next;
				}
			}
			for (HashEntry front : other.elementData) {
				HashEntry current = front;
				while (current != null) {
					if (!this.contains(current.data)) {
						return false;
					}
					current = current.next;
				}
			}
			return true;
		} else {
			return false;
		}
	}

	public boolean contains(int value) {

		int h = hash(value);
		HashEntry current = elementData[h];
		while (current != null) {
			if (current.data == value) {
				return true;
			}
			current = current.next;
		}
		return false;
	}

	public boolean isEmpty() {
		return size == 0;
	}

	public double loadFactor() {
		return (double) size / elementData.length;
	}

	public void remove(int value) {

		int h = hash(value);

		if (elementData[h] != null) {

			if (elementData[h].data == value) {
				elementData[h] = elementData[h].next;
				size--;
			} else {

				HashEntry current = elementData[h];
				while (current.next != null && current.next.data != value) {
					current = current.next;
				}

				if (current.next != null) {
					current.next = current.next.next;
					size--;
				}
			}
		}
	}

	public int size() {
		return size;
	}

	public String toString() {
		String result = "[";
		boolean first = true;
		for (HashEntry node : elementData) {
			HashEntry current = node;
			while (current != null) {
				if (!first) {
					result += ", ";
				}
				result += current.data;
				first = false;
				current = current.next;
			}
		}
		result += "]";
		return result;
	}

	public void debug() {
		System.out.println("debug() output:");
		System.out.printf("index   data\n");
		for (int i = 0; i < elementData.length; i++) {
			System.out.printf("%5d   ", i);
			HashEntry node = elementData[i];
			if (node == null) {
				System.out.printf("%6s\n", "null");
			} else {
				boolean first = true;
				while (node != null) {
					if (!first) {
						System.out.print("  --> ");
					}
					System.out.printf("%8s", node.data);
					node = node.next;
					first = false;
				}
				System.out.println();
			}
		}
		System.out.printf("size   %d\n\n", size);
	}

	private int hash(int value) {
		return Math.abs(value) % elementData.length;
	}

	public void addAll(HashIntSet s) {
		for (int i = 0; i < s.elementData.length; i++) {
			HashEntry node = s.elementData[i];

			while (node != null) {
				if (!this.contains(node.data))
					this.add(node.data);
				node = node.next;
			}
		}
	}

	public boolean containsAll(HashIntSet s) {
		for (int i = 0; i < s.elementData.length; i++) {
			HashEntry node = s.elementData[i];

			while (node != null) {
				if (!this.contains(node.data))
					return false;
				node = node.next;
			}
		}

		return true;
	}

	private void rehash() {
		HashEntry[] newelementData = (HashEntry[]) new HashEntry[2 * elementData.length];
		HashEntry[] old = elementData;
		elementData = newelementData;
		size = 0;
		for (HashEntry node : old) {
			while (node != null) {
				add(node.data);
				node = node.next;
			}
		}
	}

	private class HashEntry {
		public int data;
		public HashEntry next;

		public HashEntry(int data) {
			this.data = data;
		}
	}

}
